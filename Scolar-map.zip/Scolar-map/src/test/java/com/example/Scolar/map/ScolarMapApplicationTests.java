package com.example.Scolar.map;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScolarMapApplicationTests {

	@Test
	void contextLoads() {
	}

}
