package com.example.Scolar.map.model;

public enum TypeEtablissement {
    Public, 
    Privé, 
    Maternelle, 
    Secondaire, 
    Supérieur
}