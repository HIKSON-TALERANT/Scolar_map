package com.example.Scolar.map.controller;

public class EtablissementController {

}
