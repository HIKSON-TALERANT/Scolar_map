package com.example.Scolar.map.model;

import javax.persistence.*;

@Entity
public class Description {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String langue; // Langue d'enseignement
    private double fraisPreinscription;
    private String contact; 
    private String typeEtablissement; // Type de l'établissement (Privé, Public, etc.)

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLangue() {
        return langue;
    }

    public void setLangue(String langue) {
        this.langue = langue;
    }

    public double getFraisPreinscription() {
        return fraisPreinscription;
    }

    public void setFraisPreinscription(double fraisPreinscription) {
        this.fraisPreinscription = fraisPreinscription;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getTypeEtablissement() {
        return typeEtablissement;
    }

    public void setTypeEtablissement(String typeEtablissement) {
        this.typeEtablissement = typeEtablissement;
    }
}
