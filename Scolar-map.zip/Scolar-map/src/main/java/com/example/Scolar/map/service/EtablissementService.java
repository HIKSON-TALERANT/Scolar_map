package com.example.Scolar.map.service;

public class EtablissementService {

}
