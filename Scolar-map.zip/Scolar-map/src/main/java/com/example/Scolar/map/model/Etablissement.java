package com.example.Scolar.map.model;


import javax.persistence.*;

@Entity
public class Etablissement {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom; // Nom de l'établissement
    private String POBOX; // Boîte postale
    private double longitude; 
    private double latitude;
    private String image; // URL de l'image de l'établissement

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPOBOX() {
        return POBOX;
    }

    public void setPOBOX(String POBOX) {
        this.POBOX = POBOX;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}


