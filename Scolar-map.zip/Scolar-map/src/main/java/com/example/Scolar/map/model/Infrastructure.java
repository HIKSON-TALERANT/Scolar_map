package com.example.Scolar.map.model;

import javax.persistence.*;

@Entity
public class Infrastructure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String image; // URL ou chemin vers l'image de l'infrastructure
    private String nomInfrastructure; // Exemple : Cantine, Bibliothèque, Gymnase, etc.

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getNomInfrastructure() {
        return nomInfrastructure;
    }

    public void setNomInfrastructure(String nomInfrastructure) {
        this.nomInfrastructure = nomInfrastructure;
    }
}


