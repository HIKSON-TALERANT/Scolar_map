package com.example.Scolar.map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScolarMapApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScolarMapApplication.class, args);
	}

}
