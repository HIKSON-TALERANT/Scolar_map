package com.example.Scolar.map.repository;
import com.example.formapp.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Repository extends JpaRepository<Etablissement, Long> {
}

public interface DescriptionRepository extends JpaRepository<Description, Long> {
}

public interface InfrastructureRepository extends JpaRepository<Infrastructure, Long> {
}
