document.addEventListener('DOMContentLoaded', function () {
  const steps = document.querySelectorAll('.form-step');
  const nextButtons = document.querySelectorAll('.next-step');
  const prevButtons = document.querySelectorAll('.prev-step');
  let currentStep = 0;

  function updateSteps() {
    steps.forEach((step, index) => {
      step.classList.toggle('active', index === currentStep);
    });

    // Réinitialiser l'animation en réassignant la classe temporairement
    const header = steps[currentStep].querySelector('h2');
    if (header) {
      header.classList.remove('animate');
      void header.offsetWidth; // Forces un reflow pour réinitialiser l'animation
      header.classList.add('animate');
    }
  }

  nextButtons.forEach(button => {
    button.addEventListener('click', () => {
      if (currentStep < steps.length - 1) {
        currentStep++;
        updateSteps();
      }
    });
  });

  prevButtons.forEach(button => {
    button.addEventListener('click', () => {
      if (currentStep > 0) {
        currentStep--;
        updateSteps();
      }
    });
  });

  updateSteps(); // Initialize steps
});
